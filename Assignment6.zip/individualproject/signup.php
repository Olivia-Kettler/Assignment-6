<?php
session_start();
include('classes.php');
if(isset($_SESSION['user/email']{0})) header('location: members.php');
$email=new user();
$password=new user();
$data=new user();

function signup(){
	if(count($_POST) >0){
		$email->set_email($_POST['email']);
		$password->set_password($_POST['password']);
		return $data->usersignup();
	}
}

if(count($_POST)>0){
	$error=signup();
	if(isset($error{0})) echo $error;
		else header('location: signin.php');
}
?>

<form action="signup.php" method="POST">
E-Mail
<input type="email" name="email" required><br>
Password
<input type="password" name="password" required minlength="8"><br>
<button type="submit">Create Account</button>
</form>