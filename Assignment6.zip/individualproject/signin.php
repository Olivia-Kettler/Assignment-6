<?php
session_start();
include('classes.php');
$email=new user();
$password=new user();
$data=new user();

function signin(){
	if(count($_POST)>0){
		$email->set_email($_POST['email']);
		$password->set_password['password'];
		return $data->usersignin();
	}
}
	if(count($_POST)>0){
		$error=signin();
		if(isset($error{0})) echo $error;
		else echo 'Successful!';
	}
?>
<form action="signin.php" method="POST">
E-Mail
<input type="email" name="email" required><br>
Password
<input type="password" name="password" required minlength="8"><br>
<button type="submit">Sign In</button>
</form>