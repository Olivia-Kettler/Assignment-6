<?php
require_once('classes.php');
files::deleteJSON('data.json',$_GET['id']);
print_r($_POST);
?>
<html>
<a href="index.php">Home</a>
</html>